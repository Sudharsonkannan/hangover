## Now you can download the most powerful tools using this simple script
### Screenshot
![Screen](http://www.m9c.net/uploads/15563553591.jpg)
### Installations
```
git clone https://github.com/king-hacking/King-Hacking.git
cd King-Hacking
bash King-Tools.sh
```
### My Accounts
* [TELEGRAM](https://t.me/hackeer1)
* [FACEBOOK](https://www.facebook.com/king.hacking.sy)
* [INSTAGRAM](https://instagram.com/king1hacking)
